package SingletonDesignPattern;

public class GoofyDuck extends Duck {

	
	
	public GoofyDuck() {
		
	}
	
	
	
	

}
