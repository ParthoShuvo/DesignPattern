package SingletonDesignPattern;

public class DonaldDuck extends Duck {

	public DonaldDuck() {

	}

	
}
